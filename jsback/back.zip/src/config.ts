const config = {
    botURL: 'http://217.171.146.186:3002',
    self: 'https://217.171.146.186:3001',
    port: 3001
}
export default config;